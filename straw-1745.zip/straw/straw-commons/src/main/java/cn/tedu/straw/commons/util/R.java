package cn.tedu.straw.commons.util;

import lombok.Data;

import java.io.Serializable;

@Data
public class R<E> implements Serializable {

    /**
     * 响应时的状态码
     */
    private Integer state;
    /**
     * 操作失败时的提示信息
     */
    private String message;
    /**
     * 操作成功时响应到客户端的数据
     */
    private E data;

    public R() {
        super();
    }

    public R(Integer state) {
        this.state = state;
    }

    public static R ok() {
        return new R(State.OK);
    }

    public static <E> R ok(E data) {
        R r = new R();
        r.setState(State.OK);
        r.setData(data);
        return r;
    }

    public static R failure(Integer state, Throwable e) {
        R r = new R();
        r.setState(state);
        r.setMessage(e.getMessage());
        return r;
    }

    public interface State {

        /**
         * 正确
         */
        Integer OK = 2000;
        /**
         * 错误：用户名已经被注册
         */
        Integer ERR_USERNAME_DUPLICATE = 4000;
        /**
         * 错误：手机号码已经被注册
         */
        Integer ERR_PHONE_DUPLICATE = 4001;
        /**
         * 错误：邀请码错误
         */
        Integer ERR_INVITE_CODE = 4002;
        /**
         * 错误：班级已经被禁用
         */
        Integer ERR_CLASS_DISABLED = 4003;
        /**
         * 错误：插入数据失败
         */
        Integer ERR_INSERT = 4004;
        /**
         * 错误：非法的请求参数
         */
        Integer ERR_ILLEGAL_PARAMETER = 4005;
        /**
         * 错误：上传的文件为空
         */
        Integer ERR_FILE_EMPTY = 4006;
        /**
         * 错误：上传的文件大小超出了限制
         */
        Integer ERR_FILE_SIZE = 4007;
        /**
         * 错误：上传的文件类型超出了限制
         */
        Integer ERR_FILE_TYPE = 4008;
        /**
         * 错误：上传文件时出现读写错误
         */
        Integer ERR_FILE_IO = 4009;
        /**
         * 错误：上传文件的状态错误
         */
        Integer ERR_FILE_STATE = 4010;
        /**
         * 错误：尝试访问的“问题”数据不存在
         */
        Integer ERR_QUESTION_NOT_FOUND = 4011;
        /**
         * 错误：未知错误
         */
        Integer ERR_UNKNOWN = 9000;

    }

}