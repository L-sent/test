package cn.tedu.straw.commons.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class TeacherSelectOptionVO implements Serializable {

    private Integer id;
    private String nickname;

}
