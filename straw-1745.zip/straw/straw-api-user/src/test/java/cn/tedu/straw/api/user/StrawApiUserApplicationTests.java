package cn.tedu.straw.api.user;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.sql.DataSource;
import java.sql.Connection;

@SpringBootTest
class StrawApiUserApplicationTests {

    @Test
    void contextLoads() {
    }

    @Autowired(required = false)
    DataSource dataSource;

    @Test
    void getConnection() throws Exception {
        System.out.println(dataSource);
        Connection connection = dataSource.getConnection();
        System.out.println(connection);
    }

    @Test
    void bcryptEncode() {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String rawPassword = "1234";
        for (int i = 0; i < 50; i++) {
            String encodePassword = passwordEncoder.encode(rawPassword);
            System.err.println("encodePassword=" + encodePassword);
            // $2a$10$7LdRrW5q6It4F9Oxd4LDKucSXfgP9rz48UP2XrlEO70BJZ05v95GS
            // $2a$10$5ou0o6KEOiSfTInPJtN7K.nxtz1ZA1.VOwYApnTHpVDbaax//jdui
            // $2a$10$Im9/1z1jNCf31GP10E90mOBrZhaMiU2GllVvzvqsvCumUl41hMaWO
        }
    }

    @Test
    void bcryptMatches() {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String rawPassword = "1234";
        String encodePassword = "$2a$10$5ou0o6KEOiSfT8nPJtN7K.nxtz1ZA1.VOwYApnTHpVDbaax//jdui";
        boolean result = passwordEncoder.matches(rawPassword, encodePassword);
        System.err.println("原文=" + rawPassword);
        System.err.println("密码=" + encodePassword);
        System.err.println("验证结果=" + result);
    }

    @Test
    void i() {
        long start = System.currentTimeMillis();
        for (long i = 0; i < 3000000000L; i++) {
        }
        long end = System.currentTimeMillis();
        System.err.println(end - start);
    }

}
