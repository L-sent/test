package cn.tedu.straw.api.user.service;

import cn.tedu.straw.api.user.dto.RegisterStudentDTO;
import cn.tedu.straw.commons.ex.ServiceException;
import cn.tedu.straw.commons.vo.TeacherSelectOptionVO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class UserServiceTests {

    @Autowired
    IUserService service;

    @Test
    void registStudent() {
        try {
            RegisterStudentDTO registerStudentDTO = new RegisterStudentDTO();
            registerStudentDTO.setInviteCode("JSD2005-666666");
            registerStudentDTO.setNickname("javase");
            registerStudentDTO.setPhone("13134131001");
            registerStudentDTO.setPassword("1234");
            service.registerStudent(registerStudentDTO);
            System.err.println("注册成功！");
        } catch (ServiceException e) {
            System.err.println("注册失败：" + e.getClass().getName());
            System.err.println(">>> " + e.getMessage());
        }
    }

    @Test
    void getTeacherList() {
        List<TeacherSelectOptionVO> teachers = service.getTeacherList();
        System.err.println("老师列表长度：" + teachers.size());
        for (TeacherSelectOptionVO teacher : teachers) {
            System.err.println(">>> " + teacher);
        }
    }

}
