package cn.tedu.straw.api.user.mapper;

import cn.tedu.straw.commons.model.User;
import cn.tedu.straw.commons.vo.TeacherSelectOptionVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class UserMapperTests {

    @Autowired
    UserMapper mapper;

    @Test
    void insert() {
        User user = new User();
        user.setUsername("大黄");
        user.setPassword("1234");
        user.setPhone("13800138006");
        int rows = mapper.insert(user);
        System.out.println("rows=" + rows);
    }

    @Test
    void deleteById() {
        Integer id = 1;
        int rows = mapper.deleteById(id);
        System.out.println("rows=" + rows);
    }

    @Test
    void updateById() {
        User user = new User();
        user.setId(4);
        user.setPassword("123456");
        user.setGender(1);
        user.setClassId(998);
        int rows = mapper.updateById(user);
        System.out.println("rows=" + rows);
    }

    @Test
    void findByUsername() {
        String username = "admin";
        User user = mapper.findByUsername(username);
        System.out.println("user=" + user);
    }

    @Test
    void findByPhone() {
        String phone = "13000130000";
        User user = mapper.findByPhone(phone);
        System.out.println("user=" + user);
    }

    @Test
    void selectById() {
        Integer id = 4;
        User user = mapper.selectById(id);
        System.out.println("user=" + user);
    }

    @Test
    void selectByUsername() {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", "大强"); // username='小强'
        User user = mapper.selectOne(queryWrapper);
        System.out.println("user=" + user);
    }

    @Test
    void selectAllList() {
        List<User> users = mapper.selectList(null);
        for (User user : users) {
            System.out.println(user);
        }
    }

    @Test
    void findTeachers() {
        List<TeacherSelectOptionVO> teachers = mapper.findTeachers();
        System.err.println("老师列表长度：" + teachers.size());
        for (TeacherSelectOptionVO teacher : teachers) {
            System.err.println(">>> " + teacher);
        }
    }

}
