package cn.tedu.straw.api.user.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

// @Configuration
@Deprecated
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        // 不加密的密码加密器
//        // return NoOpPasswordEncoder.getInstance();
//        // BCrypt算法的密码加密器
//        return new BCryptPasswordEncoder();
//    }

//    @Override
//    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//        auth.inMemoryAuthentication()
//                // 登录用户名
//                .withUser("root")
//                // 登录密码，以下密码是未经加密的，需要使用NoOpPasswordEncoder
//                // .password("1234")
//                // 登录密码，以下密码值是基于BCrypt对1234加密得到的，需要使用BCryptPasswordEncodig
//                .password("{bcrypt}$2a$10$5ou0o6KEOiSfTInPJtN7K.nxtz1ZA1.VOwYApnTHpVDbaax//jdui")
//                // 授权，权限可以使用字符串数组来表示，字符串都是自定义的
//                .authorities("a_delete", "a_update", "u_list", "u_info")
//                // 继续配置
//                .and()
//                // 配置第2个用户，表示普通用户
//                .withUser("mike")
//                .password("{bcrypt}$2a$10$5ou0o6KEOiSfTInPJtN7K.nxtz1ZA1.VOwYApnTHpVDbaax//jdui")
//                .authorities("u_list", "u_info");
//    }

    // 注意：以下装配的对象不要声明为接口类型
    @Autowired
    UserDetailsServiceImpl userDetailsService;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // 配置验证授权
        http.authorizeRequests()
                .antMatchers("/test/admin/delete").hasAuthority("a_delete")
                .antMatchers("/test/admin/update").hasAuthority("a_update")
                .antMatchers("/test/user/list").hasAuthority("u_list")
                .antMatchers("/test/user/info").hasAuthority("u_info")
                .anyRequest().permitAll();

        // 启用登录表单
        http.formLogin();

        // 关闭跨域攻击
        http.csrf().disable();
    }

}
