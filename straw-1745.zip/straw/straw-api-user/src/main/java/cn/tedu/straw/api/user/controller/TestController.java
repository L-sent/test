package cn.tedu.straw.api.user.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class TestController {

    // http://localhost:8080/test/admin/delete
    @GetMapping("/admin/delete")
    public String delete() {
        return "admin delete";
    }

    // http://localhost:8080/test/admin/update
    @GetMapping("/admin/update")
    public String update() {
        return "admin update";
    }

    // http://localhost:8080/test/user/list
    @GetMapping("/user/list")
    public String list() {
        return "user list";
    }

    // http://localhost:8080/test/user/info
    @GetMapping("/user/info")
    public String info() {
        return "user info";
    }

}
