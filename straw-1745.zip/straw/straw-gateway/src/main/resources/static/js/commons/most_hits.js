let mostHitsApp = new Vue({
    el: '#mostHitsApp',
    data: {
        questions: [
            { id: 1, title: '测试问题1', status: 1, hits: 156, statusClass: 'text-success', statusText: '已解决' },
            { id: 2, title: '测试问题2', status: 0, hits: 132, statusClass: 'text-warning', statusText: '未回复' },
            { id: 3, title: '测试问题3', status: 2, hits: 111, statusClass: 'text-info', statusText: '未解决' }
        ]
    },
    methods: {
        loadQuestions: function () {
            // alert('准备从服务器端加载“热点问题”列表数据……');
            $.ajax({
                url: '/api-question/v1/questions/most-hits',
                success: function (json) {
                    let list = json.data;
                    let statusTexts = ['未回复', '未解决', '已解决'];
                    let statusClasses = ['text-warning', 'text-info', 'text-success'];
                    for (let i = 0; i < list.length; i++) {
                        list[i].statusText = statusTexts[list[i].status];
                        list[i].statusClass = statusClasses[list[i].status];
                    }
                    mostHitsApp.questions = list;
                }
            });
        }
    },
    created: function () {
        this.loadQuestions();
    }
});




