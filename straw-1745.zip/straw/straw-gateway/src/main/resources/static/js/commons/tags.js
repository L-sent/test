let tagsApp = new Vue({
    el: '#tagsApp',
    data: {
        tags: []
    },
    methods: {
        loadTags: function () {
            // alert("准备加载标签列表……");
            $.ajax({
                url: '/api-question/v1/tags',
                success: function(json) {
                    tagsApp.tags = json.data;
                }
            });
        }
    },
    created: function () {
        this.loadTags();
    }
});