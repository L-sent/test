$(document).ready(function () {
    $('#summernote').summernote({
        height: 300,
        tabsize: 2,
        lang: 'zh-CN',
        placeholder: '请输入问题的详细描述...',
        callbacks: {
            onImageUpload: function (files) {
                // alert('将执行自定义的上传图片回调！文件数量=' + files.length);
                if (files.length > 1) {
                    alert("一次只能选择1张图片！");
                    return;
                }

                let file = files[0];
                let data = new FormData();
                data.append('file', file);

                $.ajax({
                    url: '/api-question/v1/questions/image/upload',
                    data: data,
                    contentType: false,
                    processData: false,
                    type: 'POST',
                    success: function (json) {
                        if (json.state == 2000) {
                            // alert('上传成功！');
                            // console.log("服务器端响应的图片路径：");
                            // console.log(json.data);
                            let img = new Image(); // 得到<img>标签对象
                            img.src = json.data; // 设置<img src="xxx">
                            $('#summernote').summernote('insertNode', img);
                        } else {
                            alert(json.message);
                        }
                    }
                });
            }
        }
    });
});