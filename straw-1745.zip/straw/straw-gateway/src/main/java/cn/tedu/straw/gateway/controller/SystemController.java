package cn.tedu.straw.gateway.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SystemController {

    // http://localhost/index.html
    @GetMapping("/index.html")
    public String index() {
        // 当处理请求的方法的返回值是String时
        // -- 且没有使用@RestController注解，也没有使用@ResponseBody注解时
        // -- 返回的String就是视图名，或者，使用 redirect: 作为前缀表示重定向
        // 在SpringBoot中
        // -- 执行转发时，整合了Thymeleaf框架后
        // -- 默认的前缀就是 /templates/，默认的后缀是 .html
        // -- 与当前方法的返回值组合起来，将得到：
        // -- /templates/index.html
        return "index";
    }

    // http://localhost/question/create.html
    @GetMapping("/question/create.html")
    public String createQuestion() {
        return "question/create";
    }

    // http://localhost/question/detail.html
    @GetMapping("/question/detail.html")
    public String questionDetail() {
        return "question/detail";
    }

}





