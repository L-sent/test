package cn.tedu.straw.gateway.service;

import cn.tedu.straw.gateway.vo.PermissionVO;

import java.util.List;

public interface IPermissionService {

    /**
     * 查询某用户的权限列表
     *
     * @param username 用户名
     * @return 该用户的权限列表
     */
    List<PermissionVO> getUserPermissions(String username);

}
