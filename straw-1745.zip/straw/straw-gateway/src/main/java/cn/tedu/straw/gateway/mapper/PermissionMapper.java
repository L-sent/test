package cn.tedu.straw.gateway.mapper;

import cn.tedu.straw.gateway.vo.PermissionVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PermissionMapper {

    /**
     * 查询某用户的权限列表
     *
     * @param username 用户名
     * @return 该用户的权限列表
     */
    List<PermissionVO> findByUsername(String username);

}
