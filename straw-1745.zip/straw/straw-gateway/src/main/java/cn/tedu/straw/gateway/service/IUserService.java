package cn.tedu.straw.gateway.service;

import cn.tedu.straw.commons.model.User;

public interface IUserService {

    /**
     * 获取用户的详细信息
     *
     * @param username 用户名
     * @return 该用户的详细信息，如果用户名未注册，则返回null
     */
    User getUserInfo(String username);

}
