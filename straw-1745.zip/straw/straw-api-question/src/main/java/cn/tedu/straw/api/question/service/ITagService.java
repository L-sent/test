package cn.tedu.straw.api.question.service;

import cn.tedu.straw.commons.vo.TagVO;

import java.util.List;

public interface ITagService {

    /**
     * 查询所有的标签数据
     *
     * @return 所有标签的集合
     */
    List<TagVO> getTagList();

}
