package cn.tedu.straw.api.question.schedule;

import cn.tedu.straw.api.question.service.ITagService;
import cn.tedu.straw.api.question.util.RedisUtils;
import cn.tedu.straw.commons.vo.TagVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
@Slf4j
public class RedisTagSchedule {

    @Autowired
    RedisUtils redisUtils;
    @Autowired
    ITagService tagService;

    @Scheduled(fixedRate = 12 * 60 * 60 * 1000)
    public void updateRedisTag() {
        // 日志
        log.debug("[{}] 准备更新Redis服务器中缓存的标签列表"
                , DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now()));
        // 在Redis中“标签列表”数据的Key
        String tagListKey = "tags";
        // 删除“标签列表”数据，避免反复增加列表元素，或某些列表元素在MySQL中更新后在Redis中无法处理
        redisUtils.delete(tagListKey);
        // 从数据库中读取新的“标签列表”
        List<TagVO> tags = tagService.getTagList();
        // 遍历“标签列表”并向Redis中逐一添加数据
        for (TagVO tag : tags) {
            // 向Redis中添加数据
            redisUtils.rightPush(tagListKey, tag);
            redisUtils.set("tag" + tag.getId(), tag);
        }
        // 日志
        log.debug("[{}] 更新Redis服务器中缓存的标签列表，完成！"
                , DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now()));
    }

}
