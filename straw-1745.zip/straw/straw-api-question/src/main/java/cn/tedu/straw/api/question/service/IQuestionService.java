package cn.tedu.straw.api.question.service;

import cn.tedu.straw.api.question.dto.PostQuestionDTO;
import cn.tedu.straw.commons.model.Question;
import cn.tedu.straw.commons.vo.QuestionDetailVO;
import cn.tedu.straw.commons.vo.QuestionListItemVO;
import cn.tedu.straw.commons.vo.QuestionMostHitsVO;
import com.baomidou.mybatisplus.extension.service.IService;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author tedu.cn
 * @since 2020-09-16
 */
public interface IQuestionService extends IService<Question> {

    /**
     * 发布问题
     *
     * @param postQuestionDTO 客户端提交的请求参数
     * @param userId          当前登录的用户id
     * @param userNickname    当前登录的用户昵称
     */
    void postQuestion(PostQuestionDTO postQuestionDTO, Integer userId, String userNickname);

    /**
     * 查询热点问题列表
     *
     * @return 热点问题列表
     */
    List<QuestionMostHitsVO> getHostHitsQuestions();

    /**
     * 获取当前登录的用户的“问答”列表
     *
     * @param pageNum 页码
     * @param userId  用户的id
     * @return 该用户的“问答”列表
     */
    PageInfo<QuestionListItemVO> getMyQuestions(Integer pageNum, Integer userId);

    /**
     * 根据id查询某“问题”的详情
     *
     * @param id “问题”的id
     * @return 匹配“问题”的详情
     */
    QuestionDetailVO getQuestionDetail(Integer id);

}
