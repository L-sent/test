package cn.tedu.straw.api.question.mapper;

import cn.tedu.straw.commons.model.Answer;
import cn.tedu.straw.commons.vo.AnswerListItemVO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author tedu.cn
 * @since 2020-09-24
 */
@Repository
public interface AnswerMapper extends BaseMapper<Answer> {

    /**
     * 查询某“问题”的答案列表
     *
     * @param questionId “问题”的id
     * @return 该“问题”的答案列表
     */
    List<AnswerListItemVO> findByQuestionId(Integer questionId);

}
