package cn.tedu.straw.api.question.mapper;

import cn.tedu.straw.commons.model.Question;
import cn.tedu.straw.commons.vo.QuestionDetailVO;
import cn.tedu.straw.commons.vo.QuestionListItemVO;
import cn.tedu.straw.commons.vo.QuestionMostHitsVO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author tedu.cn
 * @since 2020-09-16
 */
@Repository
public interface QuestionMapper extends BaseMapper<Question> {

    /**
     * 根据id查询某“问题”的详情
     *
     * @param id “问题”的id
     * @return 匹配“问题”的详情，如果没有匹配的数据，则返回null
     */
    QuestionDetailVO findById(Integer id);

    /**
     * 查询热点问题列表
     *
     * @return 热点问题列表
     */
    List<QuestionMostHitsVO> findHostHitsList();

    /**
     * 查询某用户的“问题”列表
     *
     * @param userId 用户的id
     * @return 该用户的“问题”列表
     */
    List<QuestionListItemVO> findByUserId(Integer userId);

}
