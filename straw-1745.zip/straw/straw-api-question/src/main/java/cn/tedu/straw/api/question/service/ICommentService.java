package cn.tedu.straw.api.question.service;

import cn.tedu.straw.api.question.dto.PostCommentDTO;
import cn.tedu.straw.commons.model.Comment;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author tedu.cn
 * @since 2020-09-24
 */
public interface ICommentService extends IService<Comment> {

    /**
     * 发表评论
     *
     * @param postCommentDTO 评论数据
     * @param userId         当前登录的用户的id
     * @param userNickName   当前登录的用户名
     */
    void post(PostCommentDTO postCommentDTO, Integer userId, String userNickName);

}
