package cn.tedu.straw.api.question.service;

import cn.tedu.straw.api.question.dto.PostAnswerDTO;
import cn.tedu.straw.commons.model.Answer;
import cn.tedu.straw.commons.vo.AnswerListItemVO;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author tedu.cn
 * @since 2020-09-24
 */
public interface IAnswerService extends IService<Answer> {

    /**
     * 发表答案
     *
     * @param postAnswerDTO 客户端提交的答案
     * @param userId        当前登录的用户的id
     * @param userNickName  当前登录的用户名
     */
    void post(PostAnswerDTO postAnswerDTO, Integer userId, String userNickName);

    /**
     * 查询某“问题”的答案列表
     *
     * @param questionId “问题”的id
     * @return 该“问题”的答案列表
     */
    List<AnswerListItemVO> getAnswerList(Integer questionId);

}
