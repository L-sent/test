package cn.tedu.straw.api.question.service;

import cn.tedu.straw.api.question.dto.PostQuestionDTO;
import cn.tedu.straw.commons.ex.ServiceException;
import cn.tedu.straw.commons.vo.QuestionDetailVO;
import cn.tedu.straw.commons.vo.QuestionMostHitsVO;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
@Slf4j
public class QuestionServiceTests {

    @Autowired
    IQuestionService service;

    @Test
    void postQuestion() {
        try {
            PostQuestionDTO postQuestionDTO = new PostQuestionDTO()
                    .setTitle("数据库查询效率低下怎么解决")
                    .setContent("今天被面试官问倒了，好难受呀！")
                    .setTagIds(new Integer[]{2, 7, 9})
                    .setTeacherIds(new Integer[]{1, 3, 5});
            Integer userId = 20;
            String userNickName = "变形金刚";
            service.postQuestion(postQuestionDTO, userId, userNickName);
            log.debug("发布问题成功！");
        } catch (ServiceException e) {
            log.debug("发布问题失败！问题类型：{}，问题原因：{}", e.getClass().getName(), e.getMessage());
        }
    }

    @Test
    void getHostHitsQuestions() {
        List<QuestionMostHitsVO> questions = service.getHostHitsQuestions();
        log.debug("热点问题数量：{}", questions.size());
        for (QuestionMostHitsVO question : questions) {
            log.debug(">>> {}", question);
        }
    }

    @Test
    void getMyQuestions() {
        Integer pageNum = 1;
        Integer userId = 10;
        PageInfo pageInfo = service.getMyQuestions(pageNum, userId);
        log.debug("PageInfo >>> {}", pageInfo);
    }

    @Test
    void getQuestionDetail() {
        try {
            Integer id = 10000;
            QuestionDetailVO question = service.getQuestionDetail(id);
            log.debug("question >>> {}", question);
        } catch (ServiceException e) {
            log.debug("查询问题详情失败，错误类型：{}", e.getClass().getName());
            log.debug("错误原因：{}", e.getMessage());
        }
    }

}
