package cn.tedu.straw.api.question.mapper;

import cn.tedu.straw.commons.vo.QuestionDetailVO;
import cn.tedu.straw.commons.vo.QuestionListItemVO;
import cn.tedu.straw.commons.vo.QuestionMostHitsVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
@Slf4j
public class QuestionMapperTests {

    @Autowired
    QuestionMapper mapper;

    @Test
    void findById() {
        Integer id = 10;
        QuestionDetailVO question = mapper.findById(id);
        log.debug("question >>> {}", question);
    }

    @Test
    void findHostHitsList() {
        List<QuestionMostHitsVO> questions = mapper.findHostHitsList();
        log.debug("热点问题数量：{}", questions.size());
        for (QuestionMostHitsVO question : questions) {
            log.debug(">>> {}", question);
        }
    }

    @Test
    void findByUserId() {
        Integer userId = 10;
        int pageNum = 5; // 需要查询第几页的数据，使用1作为第1页的页码
        int pageSize = 3; // 每页需要显示几条数据
        PageHelper.startPage(pageNum, pageSize);
        List<QuestionListItemVO> questions = mapper.findByUserId(userId);
        PageInfo<QuestionListItemVO> pageInfo = new PageInfo<>(questions);
        log.debug("PageInfo >>> {}", pageInfo);
        //log.debug("某用户的id：{}，该用户的问题数量：{}", userId, questions.size());
        //for (QuestionListItemVO question : questions) {
        //    log.debug(">>> {}", question);
        //}
    }

}
