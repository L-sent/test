package cn.tedu.straw.api.question.service;

import cn.tedu.straw.api.question.dto.PostAnswerDTO;
import cn.tedu.straw.commons.ex.ServiceException;
import cn.tedu.straw.commons.vo.AnswerListItemVO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
@Slf4j
public class AnswerServiceTests {

    @Autowired
    IAnswerService service;

    @Test
    void post() {
        try {
            PostAnswerDTO postAnswerDTO = new PostAnswerDTO()
                    .setQuestionId(10)
                    .setContent("测试发表10号问题的答案");
            Integer userId = 1;
            String userNickName = "超人";
            service.post(postAnswerDTO, userId, userNickName);
            log.debug("发表答案成功！");
        } catch (ServiceException e) {
            log.debug("发表答案失败，错误类型：{}", e.getClass().getName());
            log.debug("原因：{}", e.getMessage());
        }
    }

    @Test
    void getAnswerList() {
        Integer questionId = 16;
        List<AnswerListItemVO> answers = service.getAnswerList(questionId);
        log.debug("根据问题id={}查询到{}个答案：", questionId, answers.size());
        for (AnswerListItemVO answer : answers) {
            log.debug("答案 >>> {}", answer);
        }
    }

}
