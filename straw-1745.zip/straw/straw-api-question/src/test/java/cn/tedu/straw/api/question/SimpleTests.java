package cn.tedu.straw.api.question;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

public class SimpleTests {

    @Test
    void arraysTest() {
        Integer[] tagIds = {1, 2, 5};
        String tagIdsString = Arrays.toString(tagIds);
        String result = tagIdsString.substring(1, tagIdsString.length() - 1);
        System.err.println(result);
    }

}
